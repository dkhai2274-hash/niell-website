NİELL WEBSITE — QUICK START

1. Open index.html in a browser to preview the website.
2. Open index.html in a text/code editor.
3. Find the STORE section in the script and replace:
   - whatsapp: your WhatsApp number in international format without + or spaces (Malaysia example: 60123456789)
   - instagram: your real Instagram profile URL
4. Find the PRODUCTS array and set each product's actual price and correct product image URL.
5. Publish free using GitHub Pages:
   - Create/sign in to GitHub.
   - Create a new public repository named niell-website.
   - Upload index.html.
   - Open Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
   - GitHub will provide your public website URL.

NOTES
- This is a static storefront with a working cart and WhatsApp order handoff.
- WhatsApp checkout is not an automatic payment gateway. Confirm stock, shipping and payment with customers in chat.
- Product images currently use illustrative online editorial images; replace them with your own accurate NIELL product photography before launch.
- Prices are intentionally left unset because the final selling prices have not been confirmed.
